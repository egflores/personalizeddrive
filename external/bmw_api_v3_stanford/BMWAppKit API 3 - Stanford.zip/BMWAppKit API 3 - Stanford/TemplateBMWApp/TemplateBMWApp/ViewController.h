//
//  ViewController.h
//  TemplateBMWApp
//
//  Created by John Jessen on 7/30/12.
//  Copyright (c) 2012 BMW Group. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
