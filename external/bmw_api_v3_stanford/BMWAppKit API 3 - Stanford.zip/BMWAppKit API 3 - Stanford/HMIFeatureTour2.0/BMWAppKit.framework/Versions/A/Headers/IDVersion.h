/*  
 *  IDVersion.h
 *  BMW Group App Integration Framework
 *  
 *  Copyright (C) 2011 Bayerische Motoren Werke Aktiengesellschaft (BMW AG). All rights reserved.
 */

extern NSString* AppKitGitRevision;
extern NSString* AppKitBuildTime;
