/*  
 *  IDSeparator.h
 *  BMW Group App Integration Framework
 *  
 *  Copyright (C) 2011 Bayerische Motoren Werke Aktiengesellschaft (BMW AG). All rights reserved.
 */

#import "IDWidget.h"

@interface IDSeparator : IDWidget

+ (id)separator;

@end
