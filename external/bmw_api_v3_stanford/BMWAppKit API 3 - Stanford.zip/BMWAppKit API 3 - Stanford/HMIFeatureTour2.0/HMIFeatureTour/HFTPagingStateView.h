#import <Foundation/Foundation.h>
#import <BMWAppKit/BMWAppKit.h>

@interface HFTPagingStateView : IDToolbarView

@end
