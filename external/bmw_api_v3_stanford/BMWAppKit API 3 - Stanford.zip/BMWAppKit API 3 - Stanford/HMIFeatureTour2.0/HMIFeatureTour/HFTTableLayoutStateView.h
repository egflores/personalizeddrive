#import <Foundation/Foundation.h>
#import <BMWAppKit/BMWAppKit.h>

@interface HFTTableLayoutStateView : IDTableLayoutView

@end
