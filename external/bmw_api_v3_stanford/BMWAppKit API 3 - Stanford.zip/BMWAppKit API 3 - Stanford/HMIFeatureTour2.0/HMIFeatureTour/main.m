//
//  main.m
//  HMIFeatureTour
//
//  Created by Ramos Ernesto, (Ernesto.Ramos@partner.bmw.de) on 12.03.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HFTAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HFTAppDelegate class]));
    }
}
